using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy : MonoBehaviour
{
    public int maxhealth =30;
    public Animator animator;
    public bool facingleft = true;
    public float moveSpeed = 2f;
    public float chaseSpeed = 2.5f;
    public Transform checkPoint;       
    public float distance = 1f;        
    public LayerMask layerMask;        public Transform player;           
    public float attackRange = 10f; 
    private bool inRange = false;
    public float retrieveDistance = 2.5f;
    public Transform attackPoint;
    public float attackRadius = 1f;
    public LayerMask attackLayer;  
    public AudioSource swordsound;


    void Update()
    {
        if(FindObjectOfType<GameManager>().isGameActive==false)
        {
            return;
        }
         if (maxhealth <= 0)
        {
            die();
        }
        if (player == null) return;

        inRange = Vector2.Distance(transform.position, player.position) <= attackRange;

        if (inRange)
        {
            if (player.position.x > transform.position.x && !facingleft)
            {
                Flip();
            }
            else if (player.position.x < transform.position.x && facingleft)
            {
                Flip();
            }

            if (Vector2.Distance(transform.position, player.position) > retrieveDistance)
            {
                animator.SetBool("attack1", false);
                transform.position = Vector2.MoveTowards(transform.position, player.position, chaseSpeed * Time.deltaTime);
            }
            else
            {
                animator.SetBool("attack1", true);
            }
        }
        else
        {
            Patrol();
        }
    }
      public void attack()
{
    Collider2D colInfo = Physics2D.OverlapCircle(attackPoint.position, attackRadius, attackLayer);
    if (colInfo != null)
    {
        Debug.Log("Attack hit: " + colInfo.gameObject.name); 

        hero player = colInfo.gameObject.GetComponent<hero>();
        if (player != null)
        {

            player.takedamage(10);
            
        }
    }
}
public void takedamage(int damage)
{
    if (maxhealth <= 0) return;

    maxhealth -= damage;

    if (swordsound != null)
    {
        swordsound.Play();
    }

    if (maxhealth <= 0)
    {
        die();
        Destroy(this.gameObject);
    }
}


    void die()
    {
        Debug.Log(this.transform.name + "die");
    }    void Patrol()
    {
        if (facingleft)
        {
            transform.Translate(Vector2.right * moveSpeed * Time.deltaTime);
        }
        else
        {
            transform.Translate(Vector2.left * moveSpeed * Time.deltaTime);
        }

        RaycastHit2D hit = Physics2D.Raycast(checkPoint.position, Vector2.down, distance, layerMask);

        if (!hit)  
        {
            Flip();
        }
    }

    void Flip()
    {
        facingleft = !facingleft; 
        Vector3 newScale = transform.localScale;
        newScale.x *= -1;         
        transform.localScale = newScale;
    }

    private void OnDrawGizmosSelected()
    {
        if (checkPoint == null) return;

        Gizmos.color = Color.black;
        Gizmos.DrawRay(checkPoint.position, Vector2.down * distance);

        Gizmos.color = Color.blue;
        Gizmos.DrawWireSphere(transform.position, attackRange);

        if (attackPoint != null)
        {
            Gizmos.color = Color.red;
            Gizmos.DrawWireSphere(attackPoint.position, attackRadius);
        }
    }
}
