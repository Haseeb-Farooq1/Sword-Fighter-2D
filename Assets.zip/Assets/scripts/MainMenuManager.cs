using UnityEngine;
using UnityEngine.SceneManagement;

public class MainMenuManager : MonoBehaviour
{
    // Play the game (load the Main Scene)
    public void PlayGame()
    {
        SceneManager.LoadScene("project"); // Make sure this matches your main game scene name
    }


    public void QuitGame()
    {
        Debug.Log("Quit Game");
        Application.Quit(); // This works in a build, not in the editor
    }
}
