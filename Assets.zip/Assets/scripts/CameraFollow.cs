using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraFollow : MonoBehaviour
{
    public Transform player;          // Reference to the player's transform
    public Vector3 offset = new Vector3(0f, 2f, -10f); // Offset from the player
    public float smoothSpeed = 5f;    // How smoothly the camera follows the player

    void LateUpdate()
    {
        if (player != null)
        {
            // Desired position for the camera
            Vector3 desiredPosition = player.position + offset;

            // Smoothly move the camera towards the desired position
            Vector3 smoothedPosition = Vector3.Lerp(transform.position, desiredPosition, smoothSpeed * Time.deltaTime);

            // Set the camera's position
            transform.position = smoothedPosition;
        }
    }
}
