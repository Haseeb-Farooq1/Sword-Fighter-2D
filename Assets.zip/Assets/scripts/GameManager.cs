using UnityEngine;
using UnityEngine.SceneManagement; // Required for scene management

public class GameManager : MonoBehaviour
{
    public bool isGameActive = true;

    // Method to trigger Game Over
    public void GameOver()
    {
        isGameActive = false;
        SceneManager.LoadScene("gameover"); // Load the Game Over scene
    }

    // Method to restart the game
    public void RestartGame()
    {
        isGameActive = true;
        SceneManager.LoadScene("project"); // Load the Main Scene
    }
    public void MainMenu()
    {
        isGameActive = true;
        SceneManager.LoadScene("MainMenu"); // Load the Main Scene
    }
}
