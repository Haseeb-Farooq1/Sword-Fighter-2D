using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Follow : MonoBehaviour
{
    public Transform player;          
    public Vector3 offset = new Vector3(0f, 2f, -10f);
    public float smoothSpeed = 5f;    
    public float maxY = 4.9f;       

    void LateUpdate()
    {
        if (player != null)
        {
            Vector3 desiredPosition = player.position + offset;

            desiredPosition.y = Mathf.Clamp(desiredPosition.y, float.MinValue, maxY);

            Vector3 smoothedPosition = Vector3.Lerp(transform.position, desiredPosition, smoothSpeed * Time.deltaTime);

            transform.position = smoothedPosition;
        }
    }
}
