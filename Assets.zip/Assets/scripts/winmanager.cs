using UnityEngine;
using UnityEngine.SceneManagement;  // Required for scene management

public class WinManager : MonoBehaviour
{
    // Method to load the main menu scene
    public void LoadMainMenu()
    {
        SceneManager.LoadScene("MainMenu");  // Make sure your main menu scene is named "MainMenu"
    }

    // Method to restart the game
    public void RestartGame()
    {
        SceneManager.LoadScene("project");  // Make sure your main game scene is named "MainScene"
    }

    // Method to quit the game (for standalone builds)
    public void QuitGame()
    {
        Debug.Log("Game is quitting...");
        Application.Quit();
    }
}
