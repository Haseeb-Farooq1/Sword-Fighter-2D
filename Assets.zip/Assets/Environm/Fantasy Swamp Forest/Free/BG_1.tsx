<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="BG_1" tilewidth="16" tileheight="16" tilecount="3000" columns="120">
 <image source="BG_1/BG_1.png" width="1929" height="400"/>
</tileset>
